//MimeTypeArray对象
MimeTypeArray=function MimeTypeArray(){return bodavm.toolsFunc.throwError("TypeError","Illegal constructor")}
bodavm.toolsFunc.safeProto(MimeTypeArray,"MimeTypeArray");
bodavm.toolsFunc.defineProperty(MimeTypeArray.prototype,"length",{configurable:true, enumerable:true, get:function length () {return bodavm.toolsFunc.dispatch(this,MimeTypeArray.prototype,"MimeTypeArray","length_get",arguments)},set:undefined});
bodavm.toolsFunc.defineProperty(MimeTypeArray.prototype,"item",{configurable:true, enumerable:true, writable:true, value:function item() {return bodavm.toolsFunc.dispatch(this,MimeTypeArray.prototype,"MimeTypeArray","item",arguments)}});
bodavm.toolsFunc.defineProperty(MimeTypeArray.prototype,"namedItem",{configurable:true, enumerable:true, writable:true, value:function namedItem() {return bodavm.toolsFunc.dispatch(this,MimeTypeArray.prototype,"MimeTypeArray","namedItem",arguments)}});
