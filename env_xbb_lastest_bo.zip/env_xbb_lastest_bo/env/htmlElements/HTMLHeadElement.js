// HTMLHeadElement对象
HTMLHeadElement = function HTMLHeadElement(){return bodavm.toolsFunc.throwError("TypeError", "Illegal constructor")}
bodavm.toolsFunc.safeProto(HTMLHeadElement, "HTMLHeadElement");
HTMLHeadElement.prototype.__proto__=HTMLElement.prototype;
HTMLHeadElement.__proto__=HTMLElement;
