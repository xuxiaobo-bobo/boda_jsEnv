// HTMLSpanElement对象
HTMLSpanElement = function HTMLSpanElement(){return bodavm.toolsFunc.throwError("TypeError", "Illegal constructor")}
bodavm.toolsFunc.safeProto(HTMLSpanElement, "HTMLSpanElement");
HTMLSpanElement.prototype.__proto__=HTMLElement.prototype;
HTMLSpanElement.__proto__=HTMLElement;
