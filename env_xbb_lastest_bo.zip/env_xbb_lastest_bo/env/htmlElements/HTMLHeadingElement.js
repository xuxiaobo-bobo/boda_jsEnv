// HTMLHeadingElement对象
HTMLHeadingElement = function HTMLHeadingElement(){return bodavm.toolsFunc.throwError("TypeError", "Illegal constructor")}
bodavm.toolsFunc.safeProto(HTMLHeadingElement, "HTMLHeadingElement");
HTMLHeadingElement.prototype.__proto__=HTMLElement.prototype;
HTMLHeadingElement.__proto__=HTMLElement;
bodavm.toolsFunc.defineProperty(HTMLHeadingElement.prototype, "align", {configurable:true, enumerable:true, get:function align (){return bodavm.toolsFunc.dispatch(this, HTMLHeadingElement.prototype, "HTMLHeadingElement", "align_get", arguments)}, set:function align (){return bodavm.toolsFunc.dispatch(this, HTMLHeadingElement.prototype, "HTMLHeadingElement", "align_set", arguments)}});
