// HTMLOptGroupElement对象
HTMLOptGroupElement = function HTMLOptGroupElement(){return bodavm.toolsFunc.throwError("TypeError", "Illegal constructor")}
bodavm.toolsFunc.safeProto(HTMLOptGroupElement, "HTMLOptGroupElement");
HTMLOptGroupElement.prototype.__proto__=HTMLElement.prototype;
HTMLOptGroupElement.__proto__=HTMLElement;
bodavm.toolsFunc.defineProperty(HTMLOptGroupElement.prototype, "disabled", {configurable:true, enumerable:true, get:function disabled (){return bodavm.toolsFunc.dispatch(this, HTMLOptGroupElement.prototype, "HTMLOptGroupElement", "disabled_get", arguments)}, set:function disabled (){return bodavm.toolsFunc.dispatch(this, HTMLOptGroupElement.prototype, "HTMLOptGroupElement", "disabled_set", arguments)}});
bodavm.toolsFunc.defineProperty(HTMLOptGroupElement.prototype, "label", {configurable:true, enumerable:true, get:function label (){return bodavm.toolsFunc.dispatch(this, HTMLOptGroupElement.prototype, "HTMLOptGroupElement", "label_get", arguments)}, set:function label (){return bodavm.toolsFunc.dispatch(this, HTMLOptGroupElement.prototype, "HTMLOptGroupElement", "label_set", arguments)}});
