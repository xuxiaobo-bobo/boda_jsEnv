// HTMLUnknownElement对象
HTMLUnknownElement = function HTMLUnknownElement(){return bodavm.toolsFunc.throwError("TypeError", "Illegal constructor")}
bodavm.toolsFunc.safeProto(HTMLUnknownElement, "HTMLUnknownElement");
HTMLUnknownElement.prototype.__proto__=HTMLElement.prototype;
HTMLUnknownElement.__proto__=HTMLElement;
