// HTMLLegendElement对象
HTMLLegendElement = function HTMLLegendElement(){return bodavm.toolsFunc.throwError("TypeError", "Illegal constructor")}
bodavm.toolsFunc.safeProto(HTMLLegendElement, "HTMLLegendElement");
HTMLLegendElement.prototype.__proto__=HTMLElement.prototype;
HTMLLegendElement.__proto__=HTMLElement;
bodavm.toolsFunc.defineProperty(HTMLLegendElement.prototype, "form", {configurable:true, enumerable:true, get:function form (){return bodavm.toolsFunc.dispatch(this, HTMLLegendElement.prototype, "HTMLLegendElement", "form_get", arguments)}, set:undefined});
bodavm.toolsFunc.defineProperty(HTMLLegendElement.prototype, "align", {configurable:true, enumerable:true, get:function align (){return bodavm.toolsFunc.dispatch(this, HTMLLegendElement.prototype, "HTMLLegendElement", "align_get", arguments)}, set:function align (){return bodavm.toolsFunc.dispatch(this, HTMLLegendElement.prototype, "HTMLLegendElement", "align_set", arguments)}});
