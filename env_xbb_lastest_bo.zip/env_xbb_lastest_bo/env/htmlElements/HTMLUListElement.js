// HTMLUListElement对象
HTMLUListElement = function HTMLUListElement(){return bodavm.toolsFunc.throwError("TypeError", "Illegal constructor")}
bodavm.toolsFunc.safeProto(HTMLUListElement, "HTMLUListElement");
HTMLUListElement.prototype.__proto__=HTMLElement.prototype;
HTMLUListElement.__proto__=HTMLElement;
bodavm.toolsFunc.defineProperty(HTMLUListElement.prototype, "compact", {configurable:true, enumerable:true, get:function compact (){return bodavm.toolsFunc.dispatch(this, HTMLUListElement.prototype, "HTMLUListElement", "compact_get", arguments)}, set:function compact (){return bodavm.toolsFunc.dispatch(this, HTMLUListElement.prototype, "HTMLUListElement", "compact_set", arguments)}});
bodavm.toolsFunc.defineProperty(HTMLUListElement.prototype, "type", {configurable:true, enumerable:true, get:function type (){return bodavm.toolsFunc.dispatch(this, HTMLUListElement.prototype, "HTMLUListElement", "type_get", arguments)}, set:function type (){return bodavm.toolsFunc.dispatch(this, HTMLUListElement.prototype, "HTMLUListElement", "type_set", arguments)}});
