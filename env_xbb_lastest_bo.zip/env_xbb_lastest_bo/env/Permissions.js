// Permissions对象
Permissions = function Permissions(){return bodavm.toolsFunc.throwError("TypeError", "Illegal constructor")}
bodavm.toolsFunc.safeProto(Permissions, "Permissions");
bodavm.toolsFunc.defineProperty(Permissions.prototype, "query", {configurable:true, enumerable:true, writable:true, value:function query (){return bodavm.toolsFunc.dispatch(this, Permissions.prototype, "Permissions", "query", arguments)}});
