// SVGPathElement对象
SVGPathElement = function SVGPathElement(){return bodavm.toolsFunc.throwError("TypeError", "Illegal constructor")}
bodavm.toolsFunc.safeProto(SVGPathElement, "SVGPathElement");
SVGPathElement.prototype.__proto__=SVGGeometryElement.prototype;
SVGPathElement.__proto__=SVGGeometryElement;
