// WebGLBuffer对象
WebGLBuffer = function WebGLBuffer(){return bodavm.toolsFunc.throwError("TypeError", "Illegal constructor")}
bodavm.toolsFunc.safeProto(WebGLBuffer, "WebGLBuffer");
