// WebGLShader对象
WebGLShader = function WebGLShader(){return bodavm.toolsFunc.throwError("TypeError", "Illegal constructor")}
bodavm.toolsFunc.safeProto(WebGLShader, "WebGLShader");
