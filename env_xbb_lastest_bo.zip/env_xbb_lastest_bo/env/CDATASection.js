// CDATASection对象
CDATASection = function CDATASection(){return bodavm.toolsFunc.throwError("TypeError", "Illegal constructor")}
bodavm.toolsFunc.safeProto(CDATASection, "CDATASection");
CDATASection.prototype.__proto__=Text.prototype;
CDATASection.__proto__=Text;
