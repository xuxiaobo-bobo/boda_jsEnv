// Audio对象
Audio = function Audio(){}
bodavm.toolsFunc.safeProto(Audio, "Audio");
Audio.prototype.__proto__=HTMLMediaElement.prototype;
