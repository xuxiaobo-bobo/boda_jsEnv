// BluetoothUUID对象
BluetoothUUID = function BluetoothUUID(){return bodavm.toolsFunc.throwError("TypeError", "Illegal constructor")}
bodavm.toolsFunc.safeProto(BluetoothUUID, "BluetoothUUID");
bodavm.toolsFunc.defineProperty(BluetoothUUID, "canonicalUUID", {configurable:true, enumerable:true, writable:true, value:function canonicalUUID (){return bodavm.toolsFunc.dispatch(this, BluetoothUUID, "BluetoothUUID", "canonicalUUID", arguments)}});
bodavm.toolsFunc.defineProperty(BluetoothUUID, "getCharacteristic", {configurable:true, enumerable:true, writable:true, value:function getCharacteristic (){return bodavm.toolsFunc.dispatch(this, BluetoothUUID, "BluetoothUUID", "getCharacteristic", arguments)}});
bodavm.toolsFunc.defineProperty(BluetoothUUID, "getDescriptor", {configurable:true, enumerable:true, writable:true, value:function getDescriptor (){return bodavm.toolsFunc.dispatch(this, BluetoothUUID, "BluetoothUUID", "getDescriptor", arguments)}});
bodavm.toolsFunc.defineProperty(BluetoothUUID, "getService", {configurable:true, enumerable:true, writable:true, value:function getService (){return bodavm.toolsFunc.dispatch(this, BluetoothUUID, "BluetoothUUID", "getService", arguments)}});
