// PerformancePaintTiming对象
PerformancePaintTiming = function PerformancePaintTiming(){return bodavm.toolsFunc.throwError("TypeError", "Illegal constructor")}
bodavm.toolsFunc.safeProto(PerformancePaintTiming, "PerformancePaintTiming");
PerformancePaintTiming.prototype.__proto__=PerformanceEntry.prototype;
PerformancePaintTiming.__proto__=PerformanceEntry;
