// WebGLProgram对象
WebGLProgram = function WebGLProgram(){return bodavm.toolsFunc.throwError("TypeError", "Illegal constructor")}
bodavm.toolsFunc.safeProto(WebGLProgram, "WebGLProgram");
