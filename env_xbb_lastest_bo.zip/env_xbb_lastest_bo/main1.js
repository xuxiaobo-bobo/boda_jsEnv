// const { createCanvas, loadImage } = require('canvas')
// const canvas = createCanvas(1440, 200)
// const ctx = canvas.getContext('2d')
// ctx.fillRect(100,200,300,400)
// console.log(canvas.toDataURL())


