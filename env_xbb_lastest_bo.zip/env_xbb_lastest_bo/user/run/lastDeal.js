// debugger
function get_cookie(){
    
    a={
        // b:new XMLHttpRequest().open(''),
        c:document.cookie
    }
    
    return a
}
get_cookie()