// window对象
window = {}
Object.setPrototypeOf(window, Window.prototype);
